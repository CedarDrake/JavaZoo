
/**
 * A BoopleSnoot is Mr. Jaffe's animal
 * 
 * @author Mr. Jaffe
 * @version 1.0 2017-07-14
 */
public class RogerJaffe extends Animal
{
  public RogerJaffe() {
    super("Roger Jaffe", "red", 0);
  }
  
  public String getType() {
    return "BoopleSnoot";
  }
}
